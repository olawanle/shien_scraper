from flask import Flask, request, render_template, redirect, url_for
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import json
import time
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        uploaded_file = request.files["json_file"]
        if uploaded_file.filename.endswith(".json"):
            config = json.load(uploaded_file)
            result = scrape_shein(config)
            with open("output.json", "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            return render_template("result.html", data=result)
    return render_template("index.html")

def scrape_shein(config):
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--window-size=1920,1080")

    driver = webdriver.Chrome(options=chrome_options)
    results = []

    for url in config.get("product_urls", []):
        driver.get(url)
        time.sleep(5)
        soup = BeautifulSoup(driver.page_source, "html.parser")

        title_tag = soup.find("h1")
        title = title_tag.text.strip() if title_tag else "N/A"

        script_data = soup.find("script", text=lambda t: t and "window.__INITIAL_STATE__" in t)
        product_id = sku = main_image = "N/A"

        if script_data:
            json_text = script_data.string.split("window.__INITIAL_STATE__=")[-1].split("window")[0].strip(" ;")
            try:
                json_data = json.loads(json_text)
                product_data = json_data.get("product", {}).get("goods", {})
                product_id = str(product_data.get("goods_id", "N/A"))
                sku = str(product_data.get("goods_sn", "N/A"))
                images = product_data.get("goods_imgs", [])
                if images:
                    main_image = images[0].get("ori_url", "N/A")
            except Exception as e:
                pass

        results.append({
            "title": title,
            "main_image": main_image,
            "sku": sku,
            "product_id": product_id,
            "url": url
        })

    driver.quit()
    return results

if __name__ == "__main__":
    app.run(debug=True)
